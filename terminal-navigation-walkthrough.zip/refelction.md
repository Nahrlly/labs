My labs folder is under the downloads folder for the default user on my computer.
`~` means go to home directory, ie. `users/xxome/`
The difference between `.` and `..` is that `.` refers to the current location while `..` takes you to the closest parent directory (up one level).
One absolute path from my lab is `/mnt/c/Users/xxome/Downloads/labs/terminal-navigation-walkthrough/terminal-practice`
One relative path from my lab is `/labs/terminal-navigation-walkthrough/`
My hidden files and hidden folders demonstrated that files and folders are often hidden to reduce clutter within the machine, hiding unnecesary files so that the user can easily get to files they need to.
The command which I used to redirect an output into a file was `history | grep foo > lab-files.txt`
Guessing in the terminal is dangerous because you could possibly stumble upon files that are not meant to be edited or deleted.
